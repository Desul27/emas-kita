"use server";

import { prisma } from "@/lib/prisma";
import {
  kalkulasiLengkap,
  type KalkulasiLengkapResult,
} from "@/lib/gold-bj-calculator";
import { aturanEfektif, type AturanEfektif } from "@/lib/aturan-kalkulator";
import { pastikanTokoMilik, wajibPemilik } from "@/lib/auth/guard";

// ============ TOKO ============

export interface TokoRow {
  id: string;
  nama: string;
}

export async function ambilDaftarToko(): Promise<TokoRow[]> {
  const pengguna = await wajibPemilik();
  return prisma.toko.findMany({
    where: { ownerId: pengguna.id },
    select: { id: true, nama: true },
    orderBy: { nama: "asc" },
  });
}

export async function buatToko(nama: string): Promise<TokoRow> {
  const pengguna = await wajibPemilik();
  if (!nama.trim()) {
    throw new Error("Nama toko tidak boleh kosong");
  }
  return prisma.toko.create({
    data: { nama: nama.trim(), ownerId: pengguna.id },
    select: { id: true, nama: true },
  });
}

// ============ HARGA EMAS HARIAN (dikelola dari halaman Preferensi) ============

export interface HargaTerbaru {
  hargaPerGram: number;
  tanggal: Date;
}

export async function ambilHargaTerbaru(
  tokoId: string
): Promise<HargaTerbaru | null> {
  const pengguna = await wajibPemilik();
  await pastikanTokoMilik(pengguna.id, tokoId);
  const row = await prisma.hargaEmasHarian.findFirst({
    where: { tokoId },
    orderBy: { tanggal: "desc" },
  });
  if (!row) return null;
  return { hargaPerGram: row.hargaPerGram, tanggal: row.tanggal };
}

// ============ ATURAN KALKULATOR (diatur di halaman Preferensi) ============

// Pemanggil wajib sudah memastikan toko milik pengguna.
async function muatAturan(tokoId: string): Promise<AturanEfektif> {
  const toko = await prisma.toko.findUnique({
    where: { id: tokoId },
    select: {
      modeKalkulator: true,
      bulatkanBeratKering: true,
      bulatkanKadar: true,
      cetakStruk: true,
    },
  });
  if (!toko) throw new Error("Toko tidak ditemukan");
  return aturanEfektif(toko);
}

// ============ KALKULASI (tanpa simpan) ============

export interface HitungInput {
  tokoId: string;
  beratKering: number;
  beratBasah: number;
}

export type HitungResult =
  | { ok: true; data: KalkulasiLengkapResult }
  | { ok: false; error: string };

export async function hitungKalkulatorBj(
  input: HitungInput
): Promise<HitungResult> {
  try {
    // ambilHargaTerbaru sudah memeriksa login + kepemilikan toko
    const harga = await ambilHargaTerbaru(input.tokoId);
    if (!harga) {
      return {
        ok: false,
        error:
          "Harga emas hari ini belum diset. Silakan set dulu di halaman Preferensi.",
      };
    }

    const referensi = await prisma.referensiKadar.findMany({
      select: { bj: true, kadarPersen: true },
    });
    if (referensi.length === 0) {
      return { ok: false, error: "Tabel referensi kadar belum ada isinya." };
    }

    const aturan = await muatAturan(input.tokoId);
    const hasil = kalkulasiLengkap({
      beratKering: input.beratKering,
      beratBasah: input.beratBasah,
      hargaEmasHarian: harga.hargaPerGram,
      referensi,
      aturan,
    });

    return { ok: true, data: hasil };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan";
    return { ok: false, error: message };
  }
}

// ============ GENERATE KODE TRANSAKSI ============

function formatTanggalKode(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}${m}${day}`;
}

async function generateKodeTransaksi(
  tokoId: string,
  tanggal: Date
): Promise<string> {
  const awalHari = new Date(tanggal);
  awalHari.setHours(0, 0, 0, 0);
  const akhirHari = new Date(awalHari);
  akhirHari.setDate(akhirHari.getDate() + 1);

  const jumlahHariIni = await prisma.transaksi.count({
    where: { tokoId, tanggal: { gte: awalHari, lt: akhirHari } },
  });

  const urutan = String(jumlahHariIni + 1).padStart(3, "0");
  return `TRX-${formatTanggalKode(tanggal)}-${urutan}`;
}

// ============ SIMPAN TRANSAKSI ============

export interface SimpanTransaksiInput {
  tokoId: string;
  beratKering: number;
  beratBasah: number;
  namaPelanggan?: string;
}

export type SimpanTransaksiResult =
  | {
      ok: true;
      kodeTransaksi: string;
      tanggal: string; // ISO
      data: KalkulasiLengkapResult;
      cetakStruk: boolean;
    }
  | { ok: false; error: string };

export async function simpanTransaksi(
  input: SimpanTransaksiInput
): Promise<SimpanTransaksiResult> {
  try {
    // ambilHargaTerbaru sudah memeriksa login + kepemilikan toko
    const harga = await ambilHargaTerbaru(input.tokoId);
    if (!harga) {
      return {
        ok: false,
        error:
          "Harga emas hari ini belum diset. Silakan set dulu di halaman Preferensi.",
      };
    }

    const referensi = await prisma.referensiKadar.findMany({
      select: { bj: true, kadarPersen: true },
    });
    if (referensi.length === 0) {
      return { ok: false, error: "Tabel referensi kadar belum ada isinya." };
    }

    const aturan = await muatAturan(input.tokoId);
    const hasil = kalkulasiLengkap({
      beratKering: input.beratKering,
      beratBasah: input.beratBasah,
      hargaEmasHarian: harga.hargaPerGram,
      referensi,
      aturan,
    });

    const sekarang = new Date();
    const kodeTransaksi = await generateKodeTransaksi(input.tokoId, sekarang);

    await prisma.transaksi.create({
      data: {
        kodeTransaksi,
        tanggal: sekarang,
        beratKeringAsli: hasil.beratKeringAsli,
        beratKering: hasil.beratKering, // sesudah pembulatan
        beratBasah: input.beratBasah,
        bj: hasil.bj,
        kadarAsli: hasil.kadarAsli,
        kadarPersen: hasil.kadarPersen,
        hargaPerGram: hasil.hargaPerGramEfektif,
        totalHarga: hasil.totalHarga,
        namaPelanggan: input.namaPelanggan?.trim() || null,
        tokoId: input.tokoId,
      },
    });

    return {
      ok: true,
      kodeTransaksi,
      tanggal: sekarang.toISOString(),
      data: hasil,
      cetakStruk: aturan.cetakStruk,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Terjadi kesalahan";
    return { ok: false, error: message };
  }
}

// ============ STOK HARI INI ============

export interface StokHariIni {
  totalGram: number;
  jumlahTransaksi: number;
}

export async function ambilStokHariIni(tokoId: string): Promise<StokHariIni> {
  const pengguna = await wajibPemilik();
  await pastikanTokoMilik(pengguna.id, tokoId);
  const awalHari = new Date();
  awalHari.setHours(0, 0, 0, 0);
  const akhirHari = new Date(awalHari);
  akhirHari.setDate(akhirHari.getDate() + 1);

  const agregat = await prisma.transaksi.aggregate({
    where: { tokoId, tanggal: { gte: awalHari, lt: akhirHari } },
    _sum: { beratKering: true },
    _count: true,
  });

  return {
    totalGram: agregat._sum.beratKering ?? 0,
    jumlahTransaksi: agregat._count,
  };
}
