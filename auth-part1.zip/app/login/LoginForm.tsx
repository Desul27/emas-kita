"use client";

import { useActionState, useEffect, useState } from "react";
import { masuk, type LoginState } from "./actions";

const AWAL: LoginState = {};

export default function LoginForm() {
  const [state, formAction, pending] = useActionState(masuk, AWAL);
  const [hitungMundur, setHitungMundur] = useState(0);

  // Hitung mundur supaya pengguna tahu kapan boleh mencoba lagi.
  useEffect(() => {
    if (!state.sisaDetik) return;
    setHitungMundur(state.sisaDetik);
    const timer = setInterval(() => {
      setHitungMundur((n) => (n <= 1 ? 0 : n - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [state]);

  const dijeda = hitungMundur > 0;

  return (
    <form action={formAction} className="w-full max-w-sm space-y-4">
      <div>
        <label htmlFor="identitas" className="mb-1 block text-sm">
          Username atau email
        </label>
        <input
          id="identitas"
          name="identitas"
          type="text"
          autoComplete="username"
          autoCapitalize="none"
          required
          className="w-full rounded border border-gray-300 bg-white px-3 py-2 dark:border-gray-700 dark:bg-gray-900"
        />
      </div>

      <div>
        <label htmlFor="rahasia" className="mb-1 block text-sm">
          PIN / kata sandi
        </label>
        <input
          id="rahasia"
          name="rahasia"
          type="password"
          autoComplete="current-password"
          required
          className="w-full rounded border border-gray-300 bg-white px-3 py-2 dark:border-gray-700 dark:bg-gray-900"
        />
      </div>

      {state.error && (
        <p role="alert" className="text-sm text-red-600 dark:text-red-400">
          {dijeda
            ? `Terlalu banyak percobaan gagal. Coba lagi dalam ${hitungMundur} detik.`
            : state.sisaDetik
              ? "Silakan coba lagi."
              : state.error}
        </p>
      )}

      <button
        type="submit"
        disabled={pending || dijeda}
        className="w-full rounded bg-amber-600 px-4 py-2 font-medium text-white hover:bg-amber-700 disabled:opacity-50"
      >
        {pending ? "Memeriksa..." : dijeda ? `Tunggu ${hitungMundur} detik` : "Masuk"}
      </button>
    </form>
  );
}
